### Projet Bac STI2D 2022

#### Flemme de faire ligne par ligne
Bon bha, flemme de copier tout le code html - css que j'ai fait ligne par ligne donc je vais juste faire un script python.

Alors j'ai fait le script python est il est dispo : https://github.com/linventif/tools 

06/05/2022 -> Bon, je vient de me rendre compte que j'avais 2x plus de travail que prévue, donc je vient de recrée un schéma pour le site avec une nouvelle table de couleur. Ce sera un dashbord type admin avec les statistique jour/semaine/mois/années, je vais donc devoir probablement utuliser sql, css, html, php, js et json. J'ai le sum. J'ai trouver une table color toute faite. Je me demande si je ne vais pas devoir switch sur raspberry. 



### Links
https://randomnerdtutorials.com/esp32-flash-memory
https://randomnerdtutorials.com/esp32-web-server-spiffs-spi-flash-file-system/


https://www.google.com/search?q=html+dashboard&rlz=1C1CHBD_frFR1003FR1003&sxsrf=ALiCzsYVuD5jRf3e-7XVdLNBeevm99xFuw:1651825765839&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiRkYPAusr3AhUjx4UKHQyDD2YQ_AUoAXoECAEQAw&biw=1920&bih=872&dpr=1#imgrc=32bawrKvh4oxgM
https://colorlib.com/wp/free-html5-admin-dashboard-templates/
https://blog.hubspot.com/website/best-html5-admin-dashboard-templates